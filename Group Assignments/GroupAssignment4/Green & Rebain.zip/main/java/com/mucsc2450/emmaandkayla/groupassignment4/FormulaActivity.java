package com.mucsc2450.emmaandkayla.groupassignment4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class FormulaActivity extends AppCompatActivity {
    private TextView mHeight, mRadius, mVolume;
    private String EXTRA_Height, EXTRA_Radius;
    private double r, h, v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);


        EXTRA_Height = getIntent().getExtras().getString("HeightInput");
        EXTRA_Radius = getIntent().getExtras().getString("RadiusInput");
        r = Double.parseDouble(EXTRA_Radius);
        h = Double.parseDouble(EXTRA_Height);
        v = 3.14*r*r*h;

        mHeight = (TextView)findViewById(R.id.Height_text);
        mRadius = (TextView)findViewById(R.id.Radius_text);
        mVolume = (TextView)findViewById(R.id.Calculation_text);
        mHeight.setText(getString(R.string.height_text) + " " + EXTRA_Height);
        mRadius.setText(getString(R.string.radius_text) + " " + EXTRA_Radius);
        mVolume.setText(getString(R.string.Volume_text)+ " " + v);



    }
}
