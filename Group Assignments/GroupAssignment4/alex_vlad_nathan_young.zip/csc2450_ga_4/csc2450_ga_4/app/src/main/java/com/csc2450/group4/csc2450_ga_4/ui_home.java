//0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0
//>> CSC 2450 | Group Assignment 4
//>> Alex Vlad, Nathan Young
//0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0
package com.csc2450.group4.csc2450_ga_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ui_home extends AppCompatActivity {
    private EditText edittext_height = null;
    private EditText edittext_radius = null;
    private Button button_compute_result = null;

    private static local_scope_accessor i_hate_you_java = new local_scope_accessor();

    @Override
    protected void onCreate( Bundle saved_instance ) {
        super.onCreate( saved_instance );
        setContentView( R.layout.activity_home );

        this.edittext_height = (EditText)super.findViewById( R.id.edittext_height );
        this.edittext_radius = (EditText)super.findViewById( R.id.edittext_radius );
        this.button_compute_result = (Button)super.findViewById( R.id.button_compute_result );

        this.i_hate_you_java.bind( "height_text_box", this.edittext_height );
        this.i_hate_you_java.bind( "radius_text_box", this.edittext_radius );

        this.button_compute_result.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick( View view ) {
                EditText height_textbox = (EditText)ui_home.i_hate_you_java.access( "height_text_box" );
                EditText radius_textbox = (EditText)ui_home.i_hate_you_java.access( "radius_text_box" );

                if( height_textbox.getText() == null || radius_textbox.getText() == null ) {
                    return;
                }

                final float height = Float.parseFloat( height_textbox.getText().toString() );
                final float radius = Float.parseFloat( radius_textbox.getText().toString() );

                if( height < 0.0f || radius < 0.0f ) {
                    return;
                }

                final Intent intent = new Intent( view.getContext(), ui_computation_results.class );
                intent.putExtra( "height", height );
                intent.putExtra( "radius", radius );

                startActivity( intent );
            }
        } );
    }
}
