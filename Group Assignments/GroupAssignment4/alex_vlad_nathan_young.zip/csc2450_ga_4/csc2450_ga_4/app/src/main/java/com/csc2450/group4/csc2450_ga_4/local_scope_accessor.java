package com.csc2450.group4.csc2450_ga_4;

import java.util.HashMap;

public class local_scope_accessor {
    public void bind( String binding_name, Object local_var ) {
        local_scope_accessor.bound_vars.put( binding_name, local_var );
    }

    public final Object access( String binding_name ) {
        return local_scope_accessor.bound_vars.get( binding_name );
    }

    private static HashMap< String, Object > bound_vars = new HashMap<>();
}