//0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0
//>> CSC 2450 | Group Assignment 4
//>> Alex Vlad, Nathan Young
//0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0
package com.csc2450.group4.csc2450_ga_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ui_computation_results extends AppCompatActivity {
    private TextView textview_computed_result = null;
    private TextView textview_height = null;
    private TextView textview_radius = null;

    @Override
    protected void onCreate( Bundle saved_instance ) {
        super.onCreate( saved_instance );
        setContentView( R.layout.activity_computation_results );

        final Intent intent = getIntent();
        float height = intent.getFloatExtra( "height", 0.0f );
        float radius = intent.getFloatExtra( "radius", 0.0f );

        this.textview_height = (TextView)findViewById( R.id.textview_height );
        this.textview_height.setText( "Height: " + String.valueOf( height ) );
        this.textview_radius = (TextView)findViewById( R.id.textview_radius );
        this.textview_radius.setText( "Radius: " + String.valueOf( radius ) );

        final double computed_volume = ( ( radius * radius ) * height ) * Math.PI;

        this.textview_computed_result = (TextView)findViewById( R.id.textview_computed_result );
        this.textview_computed_result.setText( String.valueOf( computed_volume ) );
    }
}
