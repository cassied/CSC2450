package com.example.souheilhallani.souheil_jose;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private Button mCalculateButton;
    private EditText mRadiusEditText, mHeightEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mCalculateButton = (Button) findViewById(R.id.Calculate);
        mRadiusEditText = (EditText) findViewbyId(R.id.mradius);
        mHeightEditText = (EditText) findViewbyId(R.id.mheight);

        mCalculateButton.setOnClickListener(new View.OnClickListener()) {
            public void click (View v){
                Intent i = new Intent(MainActivity.this, Main2Activity.class);
                i.putExtra("mradius", mRadiusEditText.getText().toString());
                i.putExtra("mheight", mHeightEditText.getText().toString());
                startActivity(i);


            }

        }
    }
