package com.tannermucsc2450.CylinderNonsense;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class DisplayCalc extends AppCompatActivity {
    double radius, height;
    public TextView r, h,v;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_calc);

        radius = Double.parseDouble(getIntent().getExtras().getString("radius"));
        height = Double.parseDouble(getIntent().getExtras().getString("height"));

        r = (TextView) findViewById(R.id.textView1);
        h = (TextView) findViewById(R.id.textView2);
        v = (TextView) findViewById(R.id.textView3);
        r.setText("Your r is: " + radius);
        h.setText("Your h is: " + height);
        v.setText("The volume is: " + (3.14 * radius*radius *height));


    }



}
