package com.example.u009.brinkerhoffjohnson;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class CalculationActivity extends AppCompatActivity {
    private TextView mCalculationText, mradius, mheight;
    private double EXTRA_Radius, EXTRA_Height;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation);

        EXTRA_Radius = Double.parseDouble(getIntent().getExtras().getString("radius"));
        EXTRA_Height = Double.parseDouble(getIntent().getExtras().getString("height"));

        mradius = (TextView) findViewById(R.id.radius);
        mheight = (TextView) findViewById(R.id.height);
        mCalculationText = (TextView) findViewById(R.id.calculation_text);



        mCalculationText.setText("Your result is " + EXTRA_Radius * EXTRA_Radius * EXTRA_Height * 3.14);
        mradius.setText("Your radius was " + EXTRA_Radius);
        mheight.setText("Your radius was " + EXTRA_Height);
    }
}
