package com.example.u009.brinkerhoffjohnson;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public EditText mradius, mheight;
    public Button mcalculate;
    public EditText mnameEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mradius = (EditText) findViewById(R.id.radius);
        mheight = (EditText) findViewById(R.id.height);
        mcalculate = (Button) findViewById(R.id.calculate);

        mcalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, CalculationActivity.class);
                i.putExtra("radius", mradius.getText().toString());
                i.putExtra("height", mheight.getText().toString());
                startActivity(i);
            }
        });


    }
}
