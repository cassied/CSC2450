package com.mucsc2450.curtisfakih.cylinder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    private TextView mcalculatedForm, mradius, mheight;
    private double EXTRA_sent_Main2, EXTRA_radius, EXTRA_height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        EXTRA_height= Double.parseDouble(getIntent().getExtras().getString("height"));
        EXTRA_radius= Double.parseDouble(getIntent().getExtras().getString("radius"));

        mheight =(TextView)findViewById(R.id.height_enter);
        mradius =(TextView)findViewById(R.id.radius_enter);
        mcalculatedForm =(TextView)findViewById(R.id.calculatedForm);

        mheight.setText("Your height is: " + EXTRA_height);
        mradius.setText("Your radius is: " + EXTRA_radius);
        mcalculatedForm.setText("Your volume is: " + (3.14*EXTRA_height*EXTRA_radius*EXTRA_radius));
    }
}
