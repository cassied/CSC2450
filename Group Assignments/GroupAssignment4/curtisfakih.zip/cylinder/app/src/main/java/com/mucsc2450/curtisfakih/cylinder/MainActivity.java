package com.mucsc2450.curtisfakih.cylinder;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button mCalculateButton;
    private EditText mRadius;
    private EditText mHeight;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCalculateButton =(Button)findViewById(R.id.calculate_button);
        mHeight = (EditText)findViewById(R.id.height_input);
        mRadius = (EditText)findViewById(R.id.radius_input);

mCalculateButton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i = new Intent(MainActivity.this, Main2Activity.class );
        i.putExtra("Radius", mRadius.getText().toString());
        i.putExtra("Height", mHeight.getText().toString());
        startActivity(i);
    }
});

        
    }
}
