package com.mucsc2450.cassie.newweek11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Contact extends AppCompatActivity {
    private TextView contactText, detailText;
    private String EXTRA_Firstname, EXTRA_Lastname, EXTRA_Gender, EXTRA_MiddleName, EXTRA_Job;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        contactText = (TextView) findViewById(R.id.contact_text);
        detailText = (TextView) findViewById(R.id.detail_text);
        EXTRA_Firstname = getIntent().getExtras().getString("firstname");
        EXTRA_Lastname = getIntent().getExtras().getString("lastname");
        EXTRA_MiddleName = getIntent().getExtras().getString("middlename");
        EXTRA_Job = getIntent().getExtras().getString("job");
        EXTRA_Gender = getIntent().getExtras().getString("gender");
        contactText.setText("Welcome, " + EXTRA_Firstname + " " + EXTRA_MiddleName + " " + EXTRA_Lastname + "!");
        detailText.setText("You are a " + EXTRA_Gender + " " + EXTRA_Job + "!");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            Intent i = new Intent(Contact.this, MainActivity.class);
            startActivity(i);

            overridePendingTransition(R.anim.right_in, R.anim.right_out);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.right_out);
    }
}