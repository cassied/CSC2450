
public class GroupAssignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int monkey = 10; monkey>0; monkey--){
			System.out.println(monkey + " little monkeys jumping on the bed");
			System.out.println("One fell off and broke his head.");
			System.out.println("Mama called the doctor and the doctor said,");
			System.out.println("No more monkeys jumping on the bed!");
			System.out.println(" ");
		}
		System.out.println("Good Night!");
	}

}
