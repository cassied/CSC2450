package green;

public class groupgreen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int m = 10;
		do{
			System.out.println(m + " little monkeys jumping on the bed. One fell off and bumped his head, Mama called the doctor, And the doctor said, No more monkeys jumping on the bed.");
			m--;
		}while (m>0);
		System.out.println("There are no more monkeys on the bed. Goodnight");
	}
}
