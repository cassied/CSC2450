package com.mucsc2450.cassie.whatsyourname;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SalutationActivity extends AppCompatActivity {

    private TextView mSalutationText;
    private String EXTRA_Sent_Salutation, EXTRA_Name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salutation);


        EXTRA_Sent_Salutation = getIntent().getExtras().getString("salutation");
        EXTRA_Name = getIntent().getExtras().getString("name");


        mSalutationText = (TextView) findViewById(R.id.salutation_text);

        mSalutationText.setText(EXTRA_Sent_Salutation + " " + EXTRA_Name);
    }
}
