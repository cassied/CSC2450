package com.mucsc2450.cassie.whatsyourname;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public Button mHelloButton, mGoodbyeButton;
    public EditText mNameEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGoodbyeButton = (Button) findViewById(R.id.goodbye_button);
        mHelloButton = (Button) findViewById(R.id.hello_button);
        mNameEditText = (EditText) findViewById(R.id.usersName);

        mHelloButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SalutationActivity.class);
                i.putExtra("salutation", getString(R.string.hello_toast));
                i.putExtra("name", mNameEditText.getText().toString());
                startActivity(i);
            }
        });


        mGoodbyeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, SalutationActivity.class);
                i.putExtra("salutation", getString(R.string.goodbye_toast));
                i.putExtra("name", mNameEditText.getText().toString());
                startActivity(i);
            }
        });
    }
}
