package com.mucsc3550.cassie.framework;

import android.graphics.Rect;

import com.mucsc3550.cassie.framework.impl.AndroidGame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class GamePlay extends Screen {
    public static boolean gameOver = false;

    enum GameState { Running, GameOver }
    GameState state = GameState.Running;
    int moves = 0, matches = 0;

    public GamePlay(Game game) {
        super(game);
        gameOver = false;
        state = GameState.Running;
        drawGameWorld();
    }

    @Override
    public void update(double deltaTime) {
        List<Input.TouchEvent> touchEvents = game.getInput().getTouchEvents();

        if(state == GameState.Running)
            updateRunning(touchEvents);
        if(state == GameState.GameOver)
            updateGameOver(touchEvents);
    }

    private void updateRunning(List<Input.TouchEvent> touchEvents) {
        int len = touchEvents.size();
        for(int i = 0; i < len; i++) {
            Input.TouchEvent event = touchEvents.get(i);
            if(event.type == Input.TouchEvent.TOUCH_UP) {
                if(event.x >= 550 && event.y >= 40 && event.y <= 165) {
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
                else if(event.y >= 166) {
                    if(Settings.soundEnabled)
                        Assets.click.play(1);

                    moves++;
                    checkGameStatus();
                }

            }
        }

        if(gameOver) {
            state = GameState.GameOver;
        }
    }

    private void updateGameOver(List<Input.TouchEvent> touchEvents) {
        int len = touchEvents.size();
        for(int i = 0; i < len; i++) {
            Input.TouchEvent event = touchEvents.get(i);
            if(event.type == Input.TouchEvent.TOUCH_UP) {
                if(event.x >= 174 && event.x <= 324 && event.y >= 784 && event.y <= 934) {
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
                if(event.x >= 404 && event.x <= 554 && event.y >= 784 && event.y <= 934) {
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                    game.setScreen(new GamePlay(game));
                }
            }
        }
    }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();

        if(state == GameState.Running)
            drawRunningUI();
        if(state == GameState.GameOver)
            drawGameOverUI();

    }

    private void drawRunningUI() {
        Graphics g = game.getGraphics();
        g.drawPixmap(Assets.move, 221, 20);

        getMoves();
    }

    private void drawGameWorld() {
        Graphics g = game.getGraphics();

        g.drawScaledPixmap(Assets.background, new Rect(0,0,719, 1279));
        g.drawScaledPixmap(Assets.settings,new Rect(600,0, 750, 150), new Rect(550,40, 675, 165));
        drawBoard(g);
    }

    private void drawGameOverUI() {
        Graphics g = game.getGraphics();
        g.drawPixmap(Assets.replay, 107, 294);
        drawHighScore(g);
        drawGameMoves(g);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {}

    private void getMoves() {
        Graphics g = game.getGraphics();

        int x = (moves >= 100 ? 270 : (moves < 10 ? 330 : 300));

        String moveString = Integer.toString(moves);

        for(int i = 0; i < moveString.length(); i++) {
            char character = moveString.charAt(i);

            int srcX = (character - '0') * 60;
            int srcWidth = 60;

            g.drawPixmap(Assets.numbers, x, 120, srcX, 0, srcWidth, 88);
            x+= srcWidth;
        }
    }

    private void drawBoard(Graphics g) {
        int x = 105;
        int y = 450;

        for(int i = 0; i < 12; i++) {
            g.drawPixmap(Assets.tile, x, y, 150, 0, 150, 150);
            x+= 180;

            if(x == 645 ) {
                x = 105;
                y = y+180;
            }
        }
    }

    private void drawHighScore(Graphics g) {
        int hs = Settings.highscores[0];
        int x = (hs < 10 ? 330 : 300);

        String hsString = Integer.toString(hs);

        for(int i = 0; i < hsString.length(); i++) {
            char character = hsString.charAt(i);

            int srcX = (character - '0') * 60;
            int srcWidth = 60;

            g.drawPixmap(Assets.numbers, x, 637, srcX, 0, srcWidth, 88);
            x+= srcWidth;
        }
    }
    private void drawGameMoves(Graphics g) {
        int x = (moves >= 100 ? 225 : (moves < 10 ? 315 : 270));

        String moveString = Integer.toString(moves);

        for(int i = 0; i < moveString.length(); i++) {
            char character = moveString.charAt(i);

            int srcX = (character - '0') * 60;
            int srcWidth = 60;

            g.drawScaledPixmap(Assets.numbers, new Rect(srcX,0, (srcX + srcWidth), 88), new Rect(x,364, x+90, 496));
            x+= 90;
        }
    }

    private void checkGameStatus() {
        if(matches == 6) {
            gameOver = true;
            Settings.addScore(moves);
            Settings.save(game.getFileIO());
        }
    }
}
