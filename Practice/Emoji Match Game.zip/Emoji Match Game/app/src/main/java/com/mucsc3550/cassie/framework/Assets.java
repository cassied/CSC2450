package com.mucsc3550.cassie.framework;

import java.util.HashMap;

public class Assets {
    public static Pixmap background;
    public static Pixmap logo;
    public static Pixmap tile;
    public static Pixmap mainMenu;
    public static Pixmap settings;
    public static Pixmap move;
    public static Pixmap replay;
    public static Pixmap help1;
    public static Pixmap help2;
    public static Pixmap help3;
    public static Pixmap numbers;
    public static Pixmap text;

    public static Sound click;
    public static Sound flip;
}
