package com.mucsc3550.cassie.framework;

import com.mucsc3550.cassie.framework.Input.TouchEvent;
import com.mucsc3550.cassie.framework.impl.AndroidGame;

import java.util.List;

public class HelpScreen extends Screen {
    public HelpScreen(Game game) {
        super(game);
    }

    @Override
    public void update(double deltaTime) {
        List<TouchEvent> touchEvents = game.getInput().getTouchEvents();
        int len = touchEvents.size();
        for(int i = 0; i < len; i++) {
            TouchEvent event = touchEvents.get(i);
            if(event.type == TouchEvent.TOUCH_UP) {
                if(event.x > 490 && event.y > 1080) {
                    game.setScreen(new HelpScreen2(game));
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                }
                if((event.x > 79 && event.x < 229) && event.y > 1080) {
                    game.setScreen(new MainMenuScreen(game));
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                }
            }
        }
    }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();

        g.drawPixmap(Assets.background, 0, 0);
        g.drawPixmap(Assets.text, 85, 80, 0, 135, 550, 130);
        g.drawPixmap(Assets.help1, 90, 250);

        g.drawPixmap(Assets.settings, 80, 1080, 600, 0, 150, 150);
        g.drawPixmap(Assets.settings, 490, 1080, 750, 0, 150, 150);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void dispose() {

    }
}
