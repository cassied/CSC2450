package com.mucsc3550.cassie.framework;

import android.graphics.Rect;

import com.mucsc3550.cassie.R;

import java.util.ResourceBundle;

public class LoadingScreen extends Screen {
    public LoadingScreen(Game game) {
        super(game);
    }

    public void update(double deltaTime) {
        Graphics g = game.getGraphics();
        Assets.background = g.newPixmap("background.png", Graphics.PixmapFormat.ARGB4444);
        Assets.logo = g.newPixmap("logo.png", Graphics.PixmapFormat.ARGB4444);
        Assets.tile = g.newPixmap("tiles.png", Graphics.PixmapFormat.ARGB4444);
        Assets.settings = g.newPixmap("settings.png", Graphics.PixmapFormat.ARGB4444);
        Assets.move = g.newPixmap("moves.png", Graphics.PixmapFormat.ARGB4444);
        Assets.replay = g.newPixmap("playagain.png", Graphics.PixmapFormat.ARGB4444);
        Assets.mainMenu = g.newPixmap("levels.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help1 = g.newPixmap("help1.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help2 = g.newPixmap("help2.png", Graphics.PixmapFormat.ARGB4444);
        Assets.help3 = g.newPixmap("help3.png", Graphics.PixmapFormat.ARGB4444);
        Assets.numbers = g.newPixmap("numbers.png", Graphics.PixmapFormat.ARGB4444);
        Assets.text = g.newPixmap("text.png", Graphics.PixmapFormat.ARGB4444);

        Assets.click = game.getAudio().newSound("click.ogg");
        Assets.flip = game.getAudio().newSound("tileflip.ogg");

        Settings.load(game.getFileIO());
        game.setScreen(new MainMenuScreen(game));
    }
    @Override
    public void present(double deltaTime) {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {}
}
