package com.mucsc3550.cassie.framework;

public interface Sound {
    public void play(float volume);

    public void dispose();
}
