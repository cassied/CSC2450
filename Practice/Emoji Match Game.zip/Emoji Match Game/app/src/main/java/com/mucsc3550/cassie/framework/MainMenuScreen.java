package com.mucsc3550.cassie.framework;

import android.graphics.Rect;
import com.mucsc3550.cassie.framework.Input.TouchEvent;
import com.mucsc3550.cassie.framework.impl.AndroidGame;

import java.util.List;

public class MainMenuScreen extends Screen {
    public MainMenuScreen(Game game) {
        super(game);
    }

    public void update(double deltaTime) {
        Graphics g = game.getGraphics();
        List<TouchEvent> touchEvents = game.getInput().getTouchEvents();

        int len = touchEvents.size();
        for(int i = 0; i < len; i++) {
            TouchEvent event = touchEvents.get(i);
            if(event.type == TouchEvent.TOUCH_UP) {
                if(inBounds(event, 100, 1080, 150, 150)) {
                    Settings.soundEnabled = !Settings.soundEnabled;
                    if(Settings.soundEnabled) Assets.click.play(1);
                }
                if(inBounds(event, 285, 1080, 150, 150)) {
                    game.setScreen(new HighScoreScreen(game));
                    if(Settings.soundEnabled) Assets.click.play(1);
                }
                if(inBounds(event, 490, 1080, 150, 150)) {
                    game.setScreen(new HelpScreen(game));
                    if(Settings.soundEnabled) Assets.click.play(1);
                }

                if(inBounds(event, 80, 820, 150, 150)) {
                    game.setScreen(new GamePlay(game));
                    if(Settings.soundEnabled) Assets.click.play(1);
                }
            }
        }
    }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();

        g.drawScaledPixmap(Assets.background, new Rect(0,0,719, 1279));

        g.drawScaledPixmap(Assets.logo, new Rect(50,75, 670, 695));


        g.drawPixmap(Assets.mainMenu, 80, 820, 0, 0, 150, 150);

        g.drawPixmap(Assets.mainMenu, 285, 820, 150, 0, 150, 150);

        g.drawPixmap(Assets.mainMenu, 490, 820, 300, 0, 150, 150);

        if(!Settings.soundEnabled)
            g.drawPixmap(Assets.settings, 80, AndroidGame.frameBufferHeight - 200, 0, 0, 150, 150);
        else
            g.drawPixmap(Assets.settings, 80, AndroidGame.frameBufferHeight - 200, 150, 0, 150, 150);


        g.drawPixmap(Assets.settings, 285, AndroidGame.frameBufferHeight - 200, 300, 0, 150, 150);

        g.drawPixmap(Assets.settings, 490, AndroidGame.frameBufferHeight - 200, 450, 0, 150, 150);


    }

    @Override
    public void pause() {
        Settings.save(game.getFileIO());
    }

    @Override
    public void resume() {}

    @Override
    public void dispose() {}

    private boolean inBounds(TouchEvent event, int x, int y, int width, int height) {
        if(event.x > x && event.x < x + width - 1 && event.y > y && event.y < y + height - 1) {
            return true;
        }
        else
            return false;
    }
}
