package com.mucsc3550.cassie.framework;

import android.content.res.AssetFileDescriptor;
import android.text.method.Touch;
import com.mucsc3550.cassie.framework.Graphics;
import com.mucsc3550.cassie.framework.Game;
import com.mucsc3550.cassie.framework.Screen;
import com.mucsc3550.cassie.framework.Input.TouchEvent;
import java.util.List;
import java.util.Set;

public class HighScoreScreen extends Screen {
    String lines[] = new String[5];

    public HighScoreScreen(Game game) {
        super(game);

        for (int j = 0; j < 5; j++) {

            lines[j] = "" + (j+1) + ". " + Settings.highscores[j];

        }
    }

    @Override
    public void update(double deltaTime) {
        List<TouchEvent> touchEvents = game.getInput().getTouchEvents();

        int len = touchEvents.size();
        for (int i = 0; i<len; i++) {
            TouchEvent event = touchEvents.get(i);
            if(event.type == TouchEvent.TOUCH_UP) {
                if((event.x > 79 && event.x < 229) && event.y > 1080) {
                    if(Settings.soundEnabled)
                        Assets.click.play(1);
                    game.setScreen(new MainMenuScreen(game));
                }
            }
        }
    }

    @Override
    public void present(double deltaTime) {
        Graphics g = game.getGraphics();
        g.drawPixmap(Assets.background, 0, 0);
        g.drawPixmap(Assets.text, 35, 80, 0, 0, 650, 130);

        int y = 300;
        for(int i = 0; i < 5; i++) {
            drawText(g, lines[i], 50, y);
            y+= 100;
        }

        g.drawPixmap(Assets.settings, 80, 1080, 600, 0, 150, 150);
    }

    private void drawText(Graphics g, String line, int x, int y) {
        int len = line.length();
        for(int i = 0; i < len; i++) {
            char character = line.charAt(i);

            if(character == ' ') {
                x+= 60;
                continue;
            }

            int srcX = 0;
            int srcWidth = 0;

            if(character == '.') {
                srcX = 600;
                srcWidth = 25;
            } else {
                srcX = (character - '0') * 60;
                srcWidth = 60;
            }

            g.drawPixmap(Assets.numbers, x, y, srcX, 0, srcWidth, 88);
            x+= srcWidth;
        }
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {}
}
