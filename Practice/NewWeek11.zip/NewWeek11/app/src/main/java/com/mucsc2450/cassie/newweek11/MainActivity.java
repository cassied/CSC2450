package com.mucsc2450.cassie.newweek11;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView mListView;
    ArrayList<Employee> employeeList;
    ArrayAdapter<Employee> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mListView = (ListView) findViewById(R.id.listView);
        //final String listItems[] = {"One", "Two", "Three", "Four", "Five"};

        employeeList = Employee.getEmployeesFromFile("employeeslocal.json", this);

        adapter = new ArrayAdapter<Employee>(MainActivity.this, R.layout.activity_listview, employeeList);
        mListView.setAdapter(adapter);

        mListView.setLongClickable(true);

        mListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View v, int position, long id) {
//                Add New Employee
                Employee empNew = new Employee();

                empNew.firstName = "Mouse";
                empNew.lastName = "Ristovski";

                employeeList.add(empNew);

//                Edit Employee
//                Employee selectedEmployee = employeeList.get(position);
//
//                selectedEmployee.firstName = selectedEmployee.firstName + " Edit";
//                selectedEmployee.lastName = selectedEmployee.lastName + " Edit";

                //Remove Employee
                //employeeList.remove(position);

                adapter.notifyDataSetChanged();
                Employee.updateJSONFile(MainActivity.this, employeeList);
                
                return true;
            }
        });

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Employee selectedEmployee = employeeList.get(position);
                Intent i = new Intent(MainActivity.this, Contact.class);
                i.putExtra("firstname", selectedEmployee.firstName);
                i.putExtra("lastname", selectedEmployee.lastName);
                startActivity(i);
                overridePendingTransition(R.anim.left_in, R.anim.left_out);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_contact) {
            Intent i = new Intent(MainActivity.this, Contact.class);
            startActivity(i);
            overridePendingTransition(R.anim.left_in, R.anim.left_out);
        }
        return super.onOptionsItemSelected(item);
    }
}