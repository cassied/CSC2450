
public class GroupAssignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i=10; i>=0;i--){
			System.out.println("There are "+i+" little monkeys jumping on the bed, one fell off and bumped his head. Mama called the doctor and the doctor said, 'NO MORE MONKEYS JUMPING ON THE BED!'");
		}
		System.out.println("Good Night!");
	}
	

}
