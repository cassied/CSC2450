package com.example.u109.quiz5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] formulas = {"Area of a Rectangle", "Volume of a Cylinder", "Circumference of a Circle", "Perimeter of a Trapezoid", "pythagorean Theorem"};
        ListAdapter mAdapter = new ArrayAdapter<String>(this, R.layout.activity_main, formulas);

        mListView = (ListView) findViewById(R.id.mListView);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                String formulas = String.valueOf(parent.getItemAtPosition(i));

                Toast.makeText(MainActivity.this, formulas,
                        Toast.LENGTH_SHORT).show();
            }
        });

    }
}
