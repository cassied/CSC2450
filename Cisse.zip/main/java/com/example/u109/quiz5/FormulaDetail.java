package com.example.u109.quiz5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class FormulaDetail extends AppCompatActivity {

    private double cylinder, circle, trapezoid, pythagorean_thrm, square;
    private EditText ,
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula_detail);


    }
}
