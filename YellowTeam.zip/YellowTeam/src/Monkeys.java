
public final class Monkeys {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int x = 10;
		
		while (x > 0) {
			
			System.out.println(x +" little monkeys jumping on the bed,");
			System.out.println("One fell off and bumped his head.");
			System.out.println("Mama called the doctor,");
			System.out.println("And the doctor said");
			System.out.println("No more monkeys jumping on the bed");
			System.out.println();
			x--;
			
		}
		
		System.out.println("No more monkeys. Goodnight");
		System.out.println("Alisa Pullum");
		System.out.println("Amadou Cisse");
		
		
	}

}
