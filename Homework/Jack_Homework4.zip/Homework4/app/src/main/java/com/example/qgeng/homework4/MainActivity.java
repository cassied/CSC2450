package com.example.qgeng.homework4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.*;

public class MainActivity extends AppCompatActivity {
    private Button mGuessButton, mResetButton;
    private EditText mGuess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int a = (int)(Math.random()*100);

        mGuessButton = (Button)findViewById(R.id.guess_button);
        mResetButton = (Button)findViewById(R.id.Reset_button);
        mGuess = (EditText)findViewById(R.id.guess);

        System.out.println ("the number you entered is : " + mGuess);

        mGuessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity.class);
                if (mGuess != a) {
                    if (mGuess > a) {
                        System.out.println("the guess number is higher");
                        startActivity (i);
                    } else {
                        System.out.println("the guess number is lower");
                        startActivity (i);
                    }
                }
                else {
                    System.out.println ("You got it right");
                    startActivity (i);
                    finish();
                }
            }
        });

        mResetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MainActivity.class);
                startActivity(i);

            }
        });

    }
}
