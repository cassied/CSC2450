/* Homework #4
Write an application where the user has to guess a secret number between 1 and 100.
1. Start by generating a random number.
2. Then, ask the user to input a number and press a button to guess the secret number.
3. After every guess, the program should tell the user via a toast message whether their
guess was too high, too low or correct.
4. When the user guesses the secret number, print out the number of tries needed.
5. Reset the number and let the user try again.
Your application must have:
● A TextView
● An EditText field
● A Button
● 3 different Toast Messages
● One Activity
● Inputs from a User
● Outputs to a user
● Error­free syntax
*/

package com.young_nathan.csc2460.csc2450_young_nathan_homework4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class activity_home extends AppCompatActivity {
    private TextView textview_info = null;
    private Button button_submit_guess = null;

    private int computers_number = 0;
    private int attempts = 0;

    @Override
    protected void onCreate(Bundle saved_state) {
        super.onCreate( saved_state );
        setContentView( R.layout.activity_home );

        this.textview_info = (TextView)findViewById( R.id.textview_info );
        assert this.textview_info == null;
        this.button_submit_guess = (Button)findViewById( R.id.button_submit_guess );
        assert this.button_submit_guess == null;

        this.textview_info.setText( "Guess between 1 & 10" );
        this.regenerate_computer_number();
        this.button_submit_guess.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick( View view ) {
                EditText edittext_user_guess = (EditText)findViewById( R.id.edittext_user_guess );
                assert edittext_user_guess == null;
                if( edittext_user_guess.getText().toString().equals( null ) ) {
                    textview_info.setText( "Enter a number, foo..." );
                    return;
                }

                final int users_number = Integer.valueOf( edittext_user_guess.getText().toString() );

                if( users_number != computers_number ) {
                    if( users_number > computers_number ) {
                        Toast.makeText( view.getContext(), "Too high", Toast.LENGTH_LONG).show();
                    } else if( users_number < computers_number ) {
                        Toast.makeText( view.getContext(), "Too low", Toast.LENGTH_LONG).show();
                    }

                    ++attempts;
                    textview_info.setText( "Wrong! Try again." );
                    return;
                }

                Toast.makeText( view.getContext(), "Correct", Toast.LENGTH_LONG).show();
                textview_info.setText( "Right. Attempts = " + attempts );
                regenerate_computer_number();
            }
        } );
    }

    private void regenerate_computer_number() {
        this.computers_number = this.generate_random_integer( 1, 10 );
    }

    private int generate_random_integer( final int min, final int max ) {
        return new Random().nextInt( ( max - min ) + 1 ) + min;
    }
}
