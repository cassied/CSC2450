package com.mucsc2450.fatema.homework4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button mguess_button;
    EditText mguessed;
    Random rand = new Random();
    int numToGuess = rand.nextInt(100)+1;
    int numTries = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mguess_button = (Button) findViewById(R.id.guess_button);
        mguessed = (EditText)findViewById(R.id.guessed);
        mguess_button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {



                int guessed = Integer.parseInt(mguessed.getText().toString());

                numTries++;
                if (guessed == numToGuess){
                        Toast.makeText(MainActivity.this, "correct", Toast.LENGTH_SHORT).show();
                        Toast.makeText(MainActivity.this, "it took you " + numTries + " tries", Toast.LENGTH_SHORT).show();
                }
                else if (guessed < numToGuess) {
                        Toast.makeText(MainActivity.this, "Guess too low", Toast.LENGTH_SHORT).show();

                }
                else if (guessed > numToGuess) {
                        Toast.makeText(MainActivity.this, "Guess too high", Toast.LENGTH_SHORT).show();

                }

            }


        });
    }
}