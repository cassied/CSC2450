package com.mucsc2450.alisa.homework4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int mrand, mguess, mlow, mhigh, r, result, count;
    private EditText minput;
    private String minput2;
    private Button msubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Random r = new Random();
        mlow = 1;
        mhigh = 20;
        result = r.nextInt(mhigh-mlow) + mlow;
        count = 0;

        mrand = result;

        msubmit = (Button) findViewById(R.id.submit_button);
        minput = (EditText) findViewById(R.id.guess);



        msubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View v) {

                count = count + 1;
                minput2 = minput.getText().toString();
                mguess = Integer.parseInt(minput2);

                if (mguess > mrand) {

                    Toast.makeText(MainActivity.this, R.string.too_high, Toast.LENGTH_SHORT).show();
                }
                else if (mguess < mrand) {

                    Toast.makeText(MainActivity.this, R.string.too_low, Toast.LENGTH_SHORT).show();
                }
                else if (mguess == mrand) {

                    Toast.makeText(MainActivity.this, "Correct! Times tried: " + count, Toast.LENGTH_SHORT).show();
                }

            }

    });
}}
