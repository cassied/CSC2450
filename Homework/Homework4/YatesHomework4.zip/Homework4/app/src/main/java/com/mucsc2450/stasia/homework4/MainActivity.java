package com.mucsc2450.stasia.homework4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {
        private Button mSubmitButton;
        private EditText mGuess;
        private int a, RandomNum;
        private int i = 0;
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            mSubmitButton = (Button) findViewById(R.id.submit_button);
            mGuess = (EditText) findViewById(R.id.Guess);
            RandomNum = (int) (Math.random() * 100 + 1);
            mSubmitButton.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    a = Integer.parseInt(mGuess.getText().toString());
                    if (RandomNum > a) {
                        Toast.makeText(MainActivity.this,
                                R.string.wrong_guess_low,
                                Toast.LENGTH_SHORT).show();
                        i = i + 1;
                    } else if (RandomNum < a) {
                        Toast.makeText(MainActivity.this,
                                R.string.wrong_guess_high,
                                Toast.LENGTH_SHORT).show();
                        i = i + 1;
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Correct! Number of attempts: "+ i,
                                Toast.LENGTH_SHORT).show();
                    }


                }

            }
            );
        }
}




