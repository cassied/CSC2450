package homework;
import java.io.*;
import java.util.*;

public class hwTwoRebain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Do you want to enter an integer or a double?");
		String userInput = sc.nextLine();
	
			System.out.println("Please enter a " + userInput);
			double number1 = sc.nextDouble();
			System.out.println("Please enter a " + userInput);
			double number2 = sc.nextDouble();
			System.out.println("Please enter a " + userInput);
			double number3 = sc.nextDouble();
			
		System.out.println(maxFunction(number1, number2, number3));
	}
	
	public static int maxFunction(int n,int x, int y){
			return Math.max(Math.max(n, x), y);	
	}
	public static double maxFunction(double n, double x, double y){
		return Math.max(Math.max(n, x), y);
	}
}
