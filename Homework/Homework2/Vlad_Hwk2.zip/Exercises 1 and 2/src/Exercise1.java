import java.io.*;
import java.util.*;
import java.lang.Math;


public class Exercise1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	
		int x, y, z;
	    
		
		System.out.println("Enter three numbers ");
	      Scanner sc = new Scanner(System.in);
	      
	      
	      x = sc.nextInt();
	      y = sc.nextInt();
	      z = sc.nextInt();
	 
	      if ( x > y && x > z)
	         System.out.println("The largest number is the first number.");
	      else if ( y > x && y > z)
	         System.out.println("The largest number is the second number.");
	      else if ( z > x && z > y)
	         System.out.println("The largest number is the third number.");
	      else   
	         System.out.println("All numbers have the same value.");
		
	      sc.close();
	      
	}

}
