import java.io.*;
import java.util.*;


public class VLAD_Quiz_2 {
	
	public double r;
	public double length;
	public double width;
	public double side;
	
		
	
	public double CircleArea(){
		return 3.14*r*r;
	}
	
	public double SquareArea(){
		return side*side;
	}

	public double RectangleArea(){
		return length*width;
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
						
		Scanner sc = new Scanner(System.in);
		{
			System.out.println("Input Circle Radius: ");
			double r = sc.nextDouble();
			double CircleArea = 3.14*r*r;
			
						
			System.out.println("Input Square Side: ");
			double side = sc.nextDouble();
			double SquareArea = side*side;
			
			System.out.println("Input Rectangle Length: ");
			double length = sc.nextDouble();			
			System.out.println("Input Rectangle Width: ");
			double width = sc.nextDouble();
			
			double RectangleArea = length*width;
			
			
			System.out.println("Circle Area is: " + CircleArea);
			System.out.println("Circle Area is: " + SquareArea);
			System.out.println("Circle Area is: " + RectangleArea);
			
			
			sc.close();
			
			
		}

			
		
		

	}

}
