import java.io.*;
import java.util.*;

public class Quiz2 {
	 
	public static final String MESSAGE = "What do you want to calculate: Circle, Square, Rectangle or exit?";



		public static void main(String[] args) {


		System.out.println(MESSAGE);
		
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			

			String userInput = sc.next();
			
			if(userInput.equalsIgnoreCase("exit")){
				System.out.println("Bye Bye!");
				sc.close();
				return;
			}

			switch (userInput) {
			case "Circle":
				userInput = "Circle";
				System.out.println("Input Circle Radius: ");
				double r = sc.nextDouble();
				double CircleArea = Math.PI * r * r;
				System.out.println("Circle Area is: " + CircleArea);
				break;

			case "Square":
				userInput = "Square";
				System.out.println("Input Square Side: ");
				double side = sc.nextDouble();
				double SquareArea = side * side;
				System.out.println("Square Area is: " + SquareArea);
				break;

			case "Rectangle":
				userInput = "Rectangle";
				System.out.println("Input Rectangle Length: ");
				double length = sc.nextDouble();
				System.out.println("Input Rectangle Width: ");
				double width = sc.nextDouble();

				double RectangleArea = length * width;
				System.out.println("Rectangle Area is: " + RectangleArea);
				break;

			default:
				System.out.println("Please try again");

			}
			System.out.println(MESSAGE);


		}
		sc.close();

	}

}
