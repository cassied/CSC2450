
public class Yates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		public double r;
		public double s;
		public double l;
		public double w;
		
		{
		Scanner sc= new sc(System.in);
		sc=("Enter a radius, side, length, and width");
		System.out.println(userInput);
	    }
		
		public double circlearea() {
			return 3.14*r*r;
		}
			
		public double squarearea() {
			return s*s;
		}
		
		public double rectanglearea() {
			l*w;
		}
	public static void main(String[] args){
		Circle circleA = new Circle();
		Square squareB = new Square();
		Rectangle rectangleC = new Rectangle();
		
		double areaA, areaB, areaC;
		areaA = circleA.areacircle();
		areaB = squareB.squarearea();
		areaC = rectangleC.rectanglearea();
		
		System.out.println("AreaA = " + areaA);
		System.out.println("AreaB = " + areaB);
		System.out.println("AreaC = " + areaC);
		
	}

	}

}
