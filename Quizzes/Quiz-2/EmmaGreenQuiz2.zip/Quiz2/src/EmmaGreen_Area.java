import java.util.*;
import java.io.*;

public class EmmaGreen_Area {

	public static double circleArea (double r){
		double cirArea = 3.14*r*r;
		return cirArea;
	}
	public static double squareArea (double s){
		double sqArea = s*s;
		return sqArea;
	}
	public static double rectangleArea (double l, double w){
		double recArea = l*w;
		return recArea;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int ans;
		
		do{
		
		System.out.println("What would you like to calculate the area of?");
		System.out.println("Enter 1 for Circle, 2 for square, or 3 for rectangle.");
		int userInput = sc.nextInt();
		
		if (userInput == 1){
			System.out.println("What is the radius of the circle?");
			double radius = sc.nextDouble();
			System.out.println("The area of the circle is: " + circleArea(radius));
		}
		else if (userInput == 2){
			System.out.println("What is the length of the side of the square?");
			double side = sc.nextDouble();
			System.out.println("The area of the square is: " + squareArea(side));
		}
		else{
			System.out.println("What is the length of the rectangle?");
			double length = sc.nextDouble();
			System.out.println("What is the width of the rectangle?");
			double width = sc.nextDouble();
			System.out.println("The area of the square is: " + rectangleArea(length, width));
		}
		
		System.out.println("Enter 1 if you would like to calcuate another area.");
		ans = sc.nextInt(); 
		
		}while (ans == 1);
		
		sc.close();
	}

}
