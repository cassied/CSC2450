package quiz2;

public class Cisse {


	
	public double length;
	public double width;
	public double r;
	public double d;
	public double side;
	
	public double square(){
		return side*side;
	}
	
	public double circle(){
		return 3.14*r*r;
	}
	
	public double rectangle(){
		return length*width;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Cisse circleA = new Cisse();
	Cisse squareA = new Cisse();
	Cisse rectangleA = new Cisse();
	
	double areaA, areaB, areaC;
	
	circleA.r = 5;
	squareA.side = 4;
	rectangleA.length = 2;
	rectangleA.width = 8;
	
	areaA = circleA.circle();
	areaB = squareA.square();
	areaC = rectangleA.rectangle();
	
	System.out.println("Circle = " + areaA);
	System.out.println("Square = " + areaB);
	System.out.println("Rectangle = " + areaC);
	
	}

}
