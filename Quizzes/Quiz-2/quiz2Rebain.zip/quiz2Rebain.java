package quiz;
import java.io.*;
import java.util.*;
public class quiz2Rebain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		//do {
			System.out.println("What is the radius of your circle?");
			double radius = sc.nextDouble();
		
			System.out.println("What are the side lengths of your square?");
			double side = sc.nextDouble();
		
			System.out.println("What is length of your rectangles base?");
			double length = sc.nextDouble();
		
			System.out.println("What is the width of your rectangle?");
			double width = sc.nextDouble();
		
			double r = radius;
			double s = side;
			double l = length;
			double w = width;
			double areacircle = 3.14*r*r;
			System.out.println("The area of your circle is " + areacircle);
			double areasquare = s*s;
			System.out.println("The area of your square is " + areasquare);
			double arearect = l*w;
			System.out.println("The area of your rectangle is " + arearect);
			
			System.out.println("Would you like to continue?");
			String answer = sc.nextLine();
			System.out.println(answer);
		//}
		//while (answer = 'yes');
	}
}
