
import java.util.*;
public class FoxQuiz2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("What kind of shape would you like to calculate the area for (enter circle, square, or rectangle)?");
		String userInput0=sc.nextLine(); 
		if (userInput0.equals("circle")){
			System.out.println("How many inputs are needed for the circle?");
			String userInput=sc.nextLine(); 
			int i=parseInt(userInput);
			int n=1; 
			while (n<=i){
				System.out.println("Enter the radius: ");
				String radius=sc.nextLine(); 
				n++; 
			}
		}
		if (userInput0.equals("square")){
			System.out.println("How many inputs are needed for the square?"); 
			String userInput2=sc.nextLine(); 
			int i2=parseInt(userInput2); 
			int n2=1; 
			while (n2<=i2){
				System.out.println("Enter the length: ");
				String length=sc.nextLine(); 
				n2++; 
			}
		if (userInput0.equals("rectangle")){
			System.out.println("How many inputs are needed for the rectangle?");
			String userInput3=sc.nextLine(); 
			int i3=parseInt(userInput3); 
			int n3=1; 
			while (n3<=i3){
				System.out.println("Enter the length of the side of the rectangle: "); 
				String length_rectangle=sc.nextLine(); 
				n3++; 
			}
		}
		}
		System.out.println("Would you like to find the area of another shape (enter yes or no)?");
		
	}
Circle circle A=new Circle(); 
CircleA.r=radius; 
areaA=circleA.area(); 
Rectangle rectangle A=new Rectangle(); 
Rectangle.length=length_rectangle(); 
Square A.w=length(); 
publie double area(){
	a=3.14*radius*radius; 
	return a; 
}
public double area_rectangle(){
	a2=length*width; 
	return a2;
}
public double area_square(){
	a3=side*side; 
	return a3; 
}

}	
}
