
public class Dennison {

	public class circle {
		
	
	public double r;
	
	public double area(){;
	return 3.14*r*r;
	}
	}
	public class square {
		public int s1;
		public int s2;
		public int area(){;
			return s1* s2;
	}
	}
	public class rectangle{
		public int l;
		public int w;
		public int area(){;
		return l*w;
		
	}
	}
	public static void main(String[] args){
		
		
		System.out.println("your rectangle's area is"+);
		System.out.println("your circle's area is"+);
		System.out.println("your square's area is"+);
		
		
	//		I know I need to use the switch/case  to ask them for input on 
	//		what shape they want to give the inputs for
		
	//		I know I need to ask them for input to set their input to
	// 		the variables s1 s2, l,w, and r. But with out notes I
	// 		have no idea what the proper syntax for usingJava's scanner is.
	
	
	// 		I just do not have that committed to memory yet. 
	
	
	//		This is where i am at in this class. To me java is most confusing
	//		in its syntax. I still dont fully understand the inside of Main, vs 
	//		outside of the main, nor how data is moved from class to method.  
	
	
	
}}
