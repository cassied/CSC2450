package homework;

public class two {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(minFunction(5,6,3));
		System.out.println(minFunction(2.0, 7.9, 9.2));
	}
	
	public static int minFunction(int n,int x, int y){
			return Math.max(Math.max(n, x), y);
		
	}
	public static double minFunction(double n, double x, double y){
		return Math.max(Math.max(n, x), y);
	}
}
