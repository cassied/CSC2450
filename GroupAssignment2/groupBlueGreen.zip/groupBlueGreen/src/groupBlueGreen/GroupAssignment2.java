package groupBlueGreen;
import java.io.*;
import java.util.*;



public class GroupAssignment2 {

	public static void takeRollcall() throws FileNotFoundException {
		
		File file = new File("student.txt");
		
		if (file.exists()){
			Scanner inFile = new Scanner(file);
			while(inFile.hasNext()){
				String line = inFile.nextLine();
				System.out.println(line);
			}
			inFile.close();
		}
		
	}
	
	public static void addStudent() throws FileNotFoundException {
		String id;
		String name;
		String rank;
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Student's ID: ");
		id = sc.nextLine();
		System.out.print("Student's Name: ");
		name = sc.nextLine();
		System.out.print("Student's Rank: ");
		rank = sc.nextLine();
				
	
		PrintStream ps = new PrintStream (new FileOutputStream("student.txt", true));
		ps.println(id+", "+name+", "+rank);
		
	
		ps.flush();
		ps.close();
		
	}
		
	
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		int userInput;
		
		do{
			
			System.out.println("What would you like to do?");
			System.out.println("Enter 1 to add a new user.");
			System.out.println("Enter 2 to take roll call.");
			System.out.println("Enter 3 to exit.");
			userInput = sc.nextInt();
			
			switch (userInput){
			
			case 1:
				
				addStudent();
				System.out.println("Student Added.");
				
				break;
				
			case 2:
				
				takeRollcall();
								
				break;
			}
		} while(userInput == 1 || userInput == 2);
		
	sc.close();	
	}

}
