import java.io.*;
import java.util.*;

public class yelloworange {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		int userInput;
		Scanner sc = new Scanner(System.in);
		File file = new File("rollCall.txt");
		
		
		
		
		do {
			System.out.println("What would you like to do?");
			System.out.println("Press 1: Take Roll Call");
			System.out.println("Press 2: Add a student");
			System.out.println("Press 3: Exit");
			userInput = sc.nextInt();
			
			switch(userInput){
			
			case 2: 
				System.out.println("What is the student's ID number?");
				String id = sc.next();
				
				System.out.println("What is the student's name?");
				String name = sc.next();
				
				System.out.println("What is the student's rank?");
				String rank = sc.next();
				
				
				PrintStream ps = new PrintStream(new FileOutputStream("rollCall.txt", true));
				ps.println(id + " " + name + " " + rank);
		   
		        ps.flush();
		        ps.close();
				
		        break;
			
			case 1:
				
				FileInputStream handle = new FileInputStream( "rolLCall.txt" );
				 
				//Construct BufferedReader from InputStreamReader
				BufferedReader br = new BufferedReader(new InputStreamReader(handle));
			 
				String line = null;
				while ((line = br.readLine()) != null) {
					System.out.println(line);
				}
			 
				br.close();
				
			break;
			
			
			}
			
			
			
			
		} while (userInput == 1 || userInput ==2);
		
		
		
		sc.close();
		
		
	}

}
