package com.mucsc2450.alisa.group_assignment_4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class CylinderActivity extends AppCompatActivity {

    private TextView mVolume_text;
    private String mEXTRA_Radius, mEXTRA_Height;
    private double manswer, mpi, mRadius, mHeight;
    private String mstring;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cylinder);

        mEXTRA_Radius = getIntent().getExtras().getString("radius");
        mEXTRA_Height = getIntent().getExtras().getString("height");
        mpi = 3.14;

        mRadius = Double.parseDouble(mEXTRA_Radius);
        mHeight = Double.parseDouble(mEXTRA_Height);

        manswer = mpi * mRadius * mRadius * mHeight;
        mstring = Double.toString(manswer);

        mVolume_text = (TextView)findViewById(R.id.volume_text);
        mVolume_text.setText("The radius entered was " + mRadius + ". The height entered was " + mHeight + ". The formula used is 3.14 * radius * radius * height. The volume is " + mstring);

    }

    }

