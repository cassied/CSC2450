package com.mucsc2450.cassie.helloworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button mCalculate;
    private EditText mRadiusEditText;
    private EditText mHeightEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCalculate = (Button) findViewById(R.id.calculate_button);
        mHeightEditText = (EditText) findViewById(R.id.heightName);
        mRadiusEditText = (EditText) findViewById(R.id.radiusName);

        mCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, formula.class);
                i.putExtra("height", mHeightEditText.getText().toString());
                i.putExtra("radius", mRadiusEditText.getText().toString());
                startActivity(i);
            }
        });
    }}






