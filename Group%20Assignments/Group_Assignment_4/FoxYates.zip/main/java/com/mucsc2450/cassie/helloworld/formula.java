package com.mucsc2450.cassie.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class formula extends AppCompatActivity {
    private TextView mHeightText, mRadiusText, mVolumeText;
    private String EXTRA_Height, EXTRA_Radius;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formula);

        EXTRA_Height=getIntent().getExtras().getString("height");
        EXTRA_Radius=getIntent().getExtras().getString("radius");



        mHeightText=(TextView)findViewById(R.id.height_text);
        mRadiusText=(TextView)findViewById(R.id.radius_text);
        mVolumeText=(TextView)findViewById(R.id.volume_text);



        double x=Double.parseDouble(EXTRA_Height);
        double y=Double.parseDouble(EXTRA_Radius);
        double v=3.14*y*x*y;

        mHeightText.setText("Height: "+EXTRA_Height);
        mRadiusText.setText("Radius: "+EXTRA_Radius);
        mVolumeText.setText("Volume: "+Double.toString(v));

    }
}
