package com.mucsc2450.cassie.week11;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class EmployeeDetail extends AppCompatActivity {

    private TextView firstName, lastName, email, phone, employee_id;
    private String EXTRA_firstName, EXTRA_lastName, EXTRA_email, EXTRA_phone, EXTRA_employee_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_detail);
        overridePendingTransition(R.anim.left_in, R.anim.left_out);

        firstName = (TextView) findViewById(R.id.firstNamePH);
        lastName = (TextView) findViewById(R.id.lastNamePH);
        email = (TextView) findViewById(R.id.emailPH);
        phone = (TextView) findViewById(R.id.phonePH);
        employee_id = (TextView) findViewById(R.id.employee_idPH);


        EXTRA_firstName = getIntent().getExtras().getString("firstname");
        EXTRA_lastName = getIntent().getExtras().getString("lastname");
        EXTRA_email = getIntent().getExtras().getString("email");
        EXTRA_phone = getIntent().getExtras().getString("phone");
        EXTRA_employee_id = getIntent().getExtras().getString("employee_id");


        firstName.setText(EXTRA_firstName);
        lastName.setText(EXTRA_lastName);
        email.setText(EXTRA_email);
        phone.setText(EXTRA_phone);
        employee_id.setText(EXTRA_employee_id);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.right_in, R.anim.right_out);
    }
}
