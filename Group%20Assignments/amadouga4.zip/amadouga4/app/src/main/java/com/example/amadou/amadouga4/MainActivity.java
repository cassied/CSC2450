package com.example.amadou.amadouga4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button mCalculate;
    private EditText mRadius;
    private EditText mHeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCalculate = (Button) findViewById(R.id.calculate_button);
        mRadius = (EditText)findViewById(R.id.Radius);
        mHeight = (EditText)findViewById(R.id.Height);

        mCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public  void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Formula.class);

                i.putExtra("RadiusInput", mRadius.getText().toString());
                i.putExtra("HeightInput", mHeight.getText().toString());
                startActivity(i);
            };
        });
    }
}
