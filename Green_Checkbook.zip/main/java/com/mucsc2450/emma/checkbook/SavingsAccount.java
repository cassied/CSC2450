package com.mucsc2450.emma.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ListViewCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SavingsAccount extends AppCompatActivity {

    ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savings_account);

        mListView = (ListView) findViewById(R.id.listview);


        String savingsTransactions[] = {"three", "two", "one"};

        ArrayAdapter<String> adapter = new ArrayAdapter(this, R.layout.listview, savingsTransactions);
        mListView.setAdapter(adapter);

    }



}




