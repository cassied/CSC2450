package com.mucsc2450.emma.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;





public class AddCheckingTrans extends AppCompatActivity {

    EditText mCheckingTransDesc, mCheckingTransAmount;
    String mCheckingDesc;
    RadioGroup mCheckingTransType;
    RadioButton mTransTypeButton, mCheckingCredit, mCheckingDebit;
    Button mCheckingTransSubmit;
    int mCheckingTransTypeSelected;
    double mCheckingAmount;


   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_checking_trans2);

        mCheckingTransDesc = (EditText) findViewById(R.id.CheckingTransDesc);
        mCheckingTransAmount = (EditText) findViewById(R.id.CheckingTransAmount);
        mCheckingTransType = (RadioGroup) findViewById(R.id.CheckingTransType);
        mCheckingTransSubmit = (Button) findViewById(R.id.CheckingTransSubmit);
        mCheckingCredit = (RadioButton) findViewById(R.id.CheckingCredit);
        mCheckingDebit = (RadioButton) findViewById(R.id.CheckingDebit);



mCheckingTransSubmit.setOnClickListener(new View.OnClickListener() {


    @Override
    public void onClick(View view) {
        //mCheckingDesc = mCheckingTransDesc.getText().toString();
        mCheckingAmount = Double.parseDouble(mCheckingTransAmount.getText().toString());

        int mCheckingTransTypeSelected_Id = mCheckingTransType.getCheckedRadioButtonId();
        mTransTypeButton = (RadioButton) findViewById(mCheckingTransTypeSelected_Id);
        if (mTransTypeButton == mCheckingCredit) {
            mCheckingTransTypeSelected = 0;
        }
        if (mTransTypeButton == mCheckingDebit) {
            mCheckingTransTypeSelected = 1;
        }


        Intent i2 = new Intent(AddCheckingTrans.this, CheckingAccount.class);
        i2.putExtra("TransDescription", mCheckingTransDesc.getText().toString());
        i2.putExtra("TransAmount", mCheckingAmount);
        i2.putExtra("TransType", mCheckingTransTypeSelected);
        startActivity(i2);



        //Toast.makeText(AddCheckingTrans.this, "Trans Type: " + mCheckingTransTypeSelected, Toast.LENGTH_SHORT).show();


    }
});




    }

}
