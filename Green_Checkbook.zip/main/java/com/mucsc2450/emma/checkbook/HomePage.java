package com.mucsc2450.emma.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        Button mCheckingButton, mSavingsButton;

        mCheckingButton = (Button) findViewById(R.id.CheckingButton);
        mSavingsButton = (Button) findViewById(R.id.SavingsButton);


        mCheckingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(HomePage.this, CheckingAccount.class);
                startActivity(i);
            }
        });

        mSavingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(HomePage.this, SavingsAccount.class);
                startActivity(i);
            }


        });


    }

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu, menu);
            return true;
        }
        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
            if (id == R.id.add_checkingTrans) {
                Intent intent = new Intent(this, AddCheckingTrans.class);
                startActivity(intent);
            }
            if (id == R.id.add_savingsTrans) {
                Intent intent = new Intent(this, AddSavingsTrans.class);
                startActivity(intent);
            }

            return super.onOptionsItemSelected(item);

        }


}

