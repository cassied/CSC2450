package com.mucsc2450.emma.checkbook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AddSavingsTrans extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_savings_trans);
    }
}
