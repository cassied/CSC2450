package com.mucsc2450.emma.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ListViewCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Arrays;

public class CheckingAccount extends AppCompatActivity {

    ListView mListView;
    String EXTRA_CheckingTransDesc, TransAmount, TransType;
    double EXTRA_CheckingTransAmount;
    int EXTRA_CheckingTransType;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checking_account);

        mListView = (ListView) findViewById(R.id.listview);



        EXTRA_CheckingTransDesc = getIntent().getExtras().getString("TransDescription");
        EXTRA_CheckingTransAmount = getIntent().getExtras().getDouble("TransAmount");
        TransAmount = Double.toString(EXTRA_CheckingTransAmount);
        EXTRA_CheckingTransType = getIntent().getExtras().getInt("TransType");
        TransType = Integer.toString(EXTRA_CheckingTransType);


        String Transactions[][] = {
                {"Description", "Amount", "Balance"},
                {EXTRA_CheckingTransDesc, TransAmount, TransType}
        };

        String checkingTransactions = Arrays.toString(Transactions[])

        ArrayAdapter<String> adapter = new ArrayAdapter(this, R.layout.listview, checkingTransactions);
        mListView.setAdapter(adapter);

    }


}
